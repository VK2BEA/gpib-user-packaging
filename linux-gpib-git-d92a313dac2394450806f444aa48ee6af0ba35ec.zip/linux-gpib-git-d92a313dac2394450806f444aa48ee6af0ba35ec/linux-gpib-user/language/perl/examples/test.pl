# To run
# Modify $minor and $pad to suite your setup
# perl test.pl
use LinuxGpib;
print LinuxGpib::ibvers()."\n";
$minor = 1;
$pad = 8;
print "pad $pad minor $minor\n";
$dev = LinuxGpib::ibdev($minor, $pad, 0, T3s, 1, 0);
$cmd = "*IDN?\n";
LinuxGpib::ibwrt($dev,$cmd,length($cmd));
LinuxGpib::ibrd($dev,$reading,127);
print $reading;
