# To run in this directory: 
# Modify pad and minor to suite your setup
# $ python3 test.py
import sys
# adapt sys.path to your setuo    
sys.path.append('/usr/local/lib64/python3.12/site-packages')
import os
import gpib
import Gpib
pad = 8
minor = 1
print (gpib.version().decode("utf-8"))
print("pad", pad, "minor", minor)
con=gpib.dev(minor, pad)
gpib.write(con, b'*IDN?')
sys.stdout.write(gpib.read(con,1000).decode("utf-8"))
gpib.close(con)
