#!/usr/bin/php 
<?php
$s="";
$u = ibvers($s) ;
print "val = $s ret = $u\n";
?>
