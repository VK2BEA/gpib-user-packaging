;; To run in this directory after install:
;; Modify pad and minor to suite your setup
;; $ export LD_LIBRARY_PATH=/usr/local/lib
;; $ export GUILE_WARN_DEPRECATED=no
;; $ guile1.8 -s test.scm
(define pad 8)
(define minor 1)
(primitive-load "gpib.scm")
(gpib:init)
(display (gpib:version)) (newline)
(for-each display (list "pad " pad " minor " minor)) (newline)
(define dev (gpib:open minor pad 0 T3s 1 0))
(gpib:write dev "*IDN?\n")
(display (gpib:read dev 256))
