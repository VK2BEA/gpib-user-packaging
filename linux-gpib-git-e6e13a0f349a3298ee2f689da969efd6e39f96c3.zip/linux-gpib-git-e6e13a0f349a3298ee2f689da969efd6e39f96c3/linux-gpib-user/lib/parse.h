#include "ibConfYacc.h"

extern unsigned int findIndex;
extern int bdid;
