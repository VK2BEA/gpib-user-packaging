# To run in this directory
# $ export LD_LIBRARY_PATH=/usr/local/lib
# Modify pad and minor to suite your setup
# $ wish test.tcl
set pad 8
set minor 1

load "$::env(LD_LIBRARY_PATH)/libgpib_tcl.so"

proc every {ms} {

    set ::foo [expr {$::foo + 1}]
    if {$::foo  > 7} { exit }
    after $ms [list every $ms]
}
set foo 0
puts [gpib version]
puts "pad $pad minor $minor"
set device [gpib dev $minor $pad 0  T3s 0 1]
gpib write $device "*IDN?\n"
set result [gpib read $device 256]
puts -nonewline $result
pack [button .b -text "test.tcl\nClick to close" -command exit]
every 1000
