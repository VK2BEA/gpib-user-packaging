import gpib

board = 1
device = 7


def query(handle, command, numbytes=100):
    gpib.write(handle, command)
    response = gpib.read(handle, numbytes).decode("utf-8")
    response = response.strip("\r\n")
    return response


def initialise_device(handle):  # set up device to assert SRQ/RQS
    gpib.write(handle, "*CLS")  # Clear status registers
    gpib.write(handle, "*SRE 32")  # Assert SRQ on Event
    gpib.write(handle, "*ESE 1")  # Set ESR on OPC
    return


def show_devid(handle):  # Show device ID
    print(query(handle, "*IDN?"))
    return


def selftest(handle, board):
    gpib.config(board, gpib.IbcAUTOPOLL, 1)  # Enable automatic serial polling
    gpib.config(handle, gpib.IbcTMO, gpib.T30s)  # Set timeout to 30 seconds
    show_devid(handle)
    initialise_device(handle)
    gpib.write(handle, "*TST?;*OPC")  # Selftest and request OPC event
    # Wait for Timeout or Request Service on device
    sta = gpib.wait(handle, gpib.TIMO | gpib.RQS)
    if (sta & gpib.TIMO) != 0:
        print("Timed out")
    else:
        print("Device asserted RQS")
        stb = gpib.serial_poll(handle)  # Read status byte
        print("stb = %#x" % (stb))
        if (stb & gpib.IbStbESB) != 0:  # Check for Event Status bit
            # Must read result of *TST? before *ESR?
            print("Selftest result: ", int(gpib.read(handle, 10)))
            esr = int(query(handle, "*ESR?"))  # Read Event Status Register
            if (esr & 1) != 0:  # Check for operation completed
                print("Device Operation Completed")
    gpib.config(board, gpib.IbcAUTOPOLL, 0)  # Disable automatic serial polling
    return


# main program
print(gpib.version())  # Show package version
handle = gpib.dev(board, device)  # Open the device
selftest(handle, board)
gpib.close(handle)
# done
