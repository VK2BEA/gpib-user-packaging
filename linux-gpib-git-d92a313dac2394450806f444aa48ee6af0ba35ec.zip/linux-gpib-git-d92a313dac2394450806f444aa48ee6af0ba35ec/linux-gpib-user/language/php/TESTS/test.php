#!/usr/bin/php 
<?php
// To run this test in the TESTS directory:
// $ php --php-ini php.ini -f test.php
// modify $pad and $minor for your setup
print ibvers()."\n";
$pad = 8;
$minor = 1;
$cmd = "*IDN?\n";
print "pad $pad minor $minor\n";
$dev = ibdev($minor, $pad, 0,T1s,1,0);
$ret = ibwrt($dev, $cmd);
if ($ret & 0x8000) {
  print gpib_error_string(iberr())."\n";
  exit;
}
$ret = ibrd($dev,$buf,256);
print $buf;
exit;
?>
